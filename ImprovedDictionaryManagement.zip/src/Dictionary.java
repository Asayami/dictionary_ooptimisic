import java.util.ArrayList;

public class Dictionary {
    protected static ArrayList<Word> Words = new ArrayList<Word>(); // dùng arraylist để quản lí mảng word
}